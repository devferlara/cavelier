from django.contrib import admin
from general.models import *


admin.site.register(Generales)

admin.site.register(Areas_de_practica)

admin.site.register(Idiomas)

admin.site.register(Cargos)
admin.site.register(Cargos_en)
admin.site.register(Cargos_fr)

admin.site.register(Areas_de_practica_fr)
admin.site.register(Areas_de_practica_en)
