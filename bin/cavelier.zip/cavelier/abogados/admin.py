from django.contrib import admin
from abogados.models import Abogado_individual


admin.site.register(Abogado_individual)