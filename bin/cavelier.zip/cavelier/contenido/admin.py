from django.contrib import admin
from contenido.models import Pagina_principal


admin.site.register(Pagina_principal)

