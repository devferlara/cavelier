from django.contrib import admin
from noticias.models import Noticias_web


admin.site.register(Noticias_web)
