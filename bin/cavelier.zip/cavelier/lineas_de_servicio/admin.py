from django.contrib import admin
from lineas_de_servicio.models import *

admin.site.register(Linea_de_servicio)
admin.site.register(Linea_individual)
